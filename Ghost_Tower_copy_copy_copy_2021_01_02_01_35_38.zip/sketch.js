var tower, towerImage, gameState = "play"
var ghost, ghostImage
var doorImage, door, climberImage, climber, doorsGroup, climbersGroup
var inv, invGroup

function preload(){
  towerImage = loadImage("tower.png")
  ghostImage = loadImage("ghost-jumping.png")
  doorImage = loadImage("door.png")
  climberImage = loadImage("climber.png")
  
}

function setup(){
  createCanvas(600,600)
  tower = createSprite(300,300)
  tower.velocityY = 1
  tower.addImage(towerImage)
  ghost = createSprite(200,200,50,50)
  ghost.addImage(ghostImage)
  ghost.scale = 0.3
  
  doorsGroup = new Group()
  climbersGroup = new Group()
  invGroup = new Group()
}

function draw(){
  background(0)
  if(gameState==="play"){
    drawSprites()
    if(tower.y>400){
      tower.y = 300
    }
    if(keyDown("left_arrow")){
      ghost.x = ghost.x-3
    }
    if(keyDown("right_arrow")){
      ghost.x = ghost.x+3
    }
  if(keyDown("space")){
      ghost.velocityY = -10
    }
  ghost.velocityY = ghost.velocityY+0.5            
  spawndoors()
    if(climbersGroup.isTouching(ghost)){
      ghost.velocityY = 0
    }
     
    if(invGroup.isTouching(ghost)||ghost.y>600){
      ghost.destroy()
      gameState = "end"
    }
  }
  if(gameState==="end"){
    stroke("yellow");
    fill("yellow");
  textSize(30); text("Game Over", 230,250)
     }

}
function spawndoors(){
  if(frameCount%240===0){
    door = createSprite(200,-50)
    door.addImage(doorImage)  
    climber = createSprite(200,10)
    inv = createSprite(200,15)
    inv.debug =   false
    inv.velocityY = 1
    climber.addImage(climberImage)
    climber.lifetime = 800
    door.lifetime = 800
    inv.lifetime = 800
    climber.velocityY = 1
    door.x = Math.round(random(120,400))
    climber.x =  door.x
    inv.x = door.x
    door.velocityY = 1
    climbersGroup.add(climber)
    doorsGroup.add(door)
    invGroup.add(inv)
    inv.width = climber.width
    inv.height = 2
    ghost.depth = door.depth
    ghost.depth = ghost.depth+1
}
}
